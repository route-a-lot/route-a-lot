package kit.route.a.lot.gui.event;

public class GeneralEvent {}