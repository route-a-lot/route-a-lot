package kit.route.a.lot.io;

import java.io.File;




public interface HeightLoader {

    /**
     * Operation load
     * 
     * @param file
     *            -
     * @return
     * @return
     */
    public void load(File file);
}
